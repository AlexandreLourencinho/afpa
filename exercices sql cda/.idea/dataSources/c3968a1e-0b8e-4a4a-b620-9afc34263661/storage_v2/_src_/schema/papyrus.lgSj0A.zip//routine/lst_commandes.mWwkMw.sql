create
    definer = root@localhost procedure lst_commandes(IN obs varchar(50))
BEGIN 
SELECT      entcom.numcom, entcom.obscom
FROM 			entcom
WHERE 		obscom LIKE CONCAT('%',obs,'%');
END;

