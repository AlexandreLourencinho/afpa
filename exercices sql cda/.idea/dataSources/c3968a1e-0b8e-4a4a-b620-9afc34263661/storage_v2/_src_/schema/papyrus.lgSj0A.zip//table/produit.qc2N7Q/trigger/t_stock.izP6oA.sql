create definer = root@localhost trigger t_stock
    after update
    on produit
    for each row
BEGIN
		DECLARE code_article CHAR(4);
		DECLARE qte_com INT;
		DECLARE stock_alerte INT;
		DECLARE stock_phy int;		
		SET code_article = NEW.codart;
		SET stock_phy = new.stkphy;
	   SET stock_alerte = (SELECT produit.stkale FROM produit WHERE produit.codart = code_article);
			IF ((stock_phy < stock_alerte) AND (code_article NOT IN (select codart FROM article_a_commander WHERE codart=code_article)))
			THEN 
					SET qte_com = (stock_alerte - stock_phy);
					INSERT INTO article_a_commander VALUES (NULL, code_article, qte_com, CURDATE());
			ELSE 
				SET qte_com = (stock_alerte-stock_phy);
				UPDATE article_a_commander SET quantite_commande = qte_com, date_insertion=CURDATE() WHERE codart=code_article;
			END if;
	END;

