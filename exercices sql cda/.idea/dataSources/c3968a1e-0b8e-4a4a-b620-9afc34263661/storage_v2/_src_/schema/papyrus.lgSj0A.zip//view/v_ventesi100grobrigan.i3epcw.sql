create view v_ventesi100grobrigan as
select `vi100`.`codart` AS `codart`,
       `vi100`.`numfou` AS `numfou`,
       `vi100`.`delliv` AS `delliv`,
       `vi100`.`qte1`   AS `qte1`,
       `vi100`.`prix1`  AS `prix1`,
       `vi100`.`qte2`   AS `qte2`,
       `vi100`.`prix2`  AS `prix2`,
       `vi100`.`qte3`   AS `qte3`,
       `vi100`.`prix3`  AS `prix3`
from `papyrus`.`v_ventesi100` `vi100`
where `vi100`.`numfou` = 120;

