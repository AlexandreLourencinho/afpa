create
    definer = root@localhost procedure ca_fournisseur(IN année int, IN numfournisseur int)
BEGIN
if numfournisseur = ANY (SELECT numfou FROM fournis) then
select      sum(qtecde*priuni*1.2) as total, nomfou as "nom fournisseur"
from        ligcom, fournis, entcom
where       ligcom.numcom = entcom.numcom
and         entcom.numfou = fournis.numfou
and         year(datcom) = année
AND 			fournis.numfou = numfournisseur;
END if ;
END;

