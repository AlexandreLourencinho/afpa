create
    definer = root@localhost procedure lst_fournis()
BEGIN 
SELECT DISTINCT entcom.numfou as "numéro fournisseur", nomfou as "nom fournisseur"

from            entcom 
join            fournis 
on              entcom.numfou = fournis.numfou;
END;

