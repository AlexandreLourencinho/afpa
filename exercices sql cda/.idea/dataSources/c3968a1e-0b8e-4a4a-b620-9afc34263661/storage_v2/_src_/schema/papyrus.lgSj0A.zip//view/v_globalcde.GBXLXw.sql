create view v_globalcde as
select `papyrus`.`ligcom`.`codart`                               AS `code de l'article`,
       sum(`papyrus`.`ligcom`.`qtecde`)                          AS `QteTot`,
       `papyrus`.`ligcom`.`priuni` * `papyrus`.`ligcom`.`qtecde` AS `PrixTot`
from `papyrus`.`ligcom`
group by `papyrus`.`ligcom`.`codart`;

