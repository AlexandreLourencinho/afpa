create
    definer = root@localhost procedure date_last_cmd(IN CLIENT varchar(40))
BEGIN
SELECT  MAX(OrderDate) AS 'Date de dernière commande'

FROM    orders, customers

WHERE   orders.CustomerID = customers.CustomerID 

AND     CompanyName = CLIENT;
END;

