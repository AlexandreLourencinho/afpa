create
    definer = root@localhost procedure avg_ship_by_client(IN anne int, IN mois int, IN CLIENT varchar(40))
begin
SELECT  FLOOR(AVG(datediff(ShippedDate,OrderDate))) AS "Délai moyen de livraison en jours"
FROM    orders 
WHERE YEAR(OrderDate) = anne
AND MONTH(Orderdate) = mois
GROUP BY CLIENT;
END;

